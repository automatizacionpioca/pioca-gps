/*
  piOca® R67 - Cloudflare Pages Worker
  Geometría vial sectorizada para map matching VISUAL.

  - Sirve los assets estáticos normalmente.
  - /__r67/sector construye/entrega un sector vial compacto.
  - Cada sector se guarda en caches.default de Cloudflare.
  - El cliente R67 nunca expone ni depende de una API key.
  - Fuente geométrica: OpenStreetMap / Overpass.
*/

const CFG = Object.freeze({
  version: 'r67-v1-20261007',
  stepLat: 0.025,
  stepLon: 0.030,

  // Cobertura por demanda: Provincia de Buenos Aires completa + CABA,
  // con margen. Sólo se consulta el pequeño sector donde realmente circula el vehículo.
  coverage: {
    south: -41.20,
    west: -63.50,
    north: -33.15,
    east: -56.50
  },

  highwayRegex:
    '^(motorway|motorway_link|trunk|trunk_link|primary|primary_link|secondary|secondary_link|tertiary|tertiary_link|unclassified|residential|living_street|road)$',

  overpass: [
    'https://overpass.private.coffee/api/interpreter',
    'https://overpass-api.de/api/interpreter'
  ],

  timeoutMs: 16000,
  cacheSeconds: 2592000 // 30 días en edge
});

// Identifica la ejecución del Worker en Cloudflare sin cambiar el protocolo R67 del cliente.
const WORKER_BUILD = 'r67-cf-overpass-post-20261107';

const TIPOS = [
  'motorway','motorway_link','trunk','trunk_link','primary','primary_link',
  'secondary','secondary_link','tertiary','tertiary_link','unclassified',
  'residential','living_street','road'
];
const TIPO_INDEX = new Map(TIPOS.map((v,i)=>[v,i]));

function json(body,status=200,extraHeaders={}){
  return new Response(JSON.stringify(body),{
    status,
    headers:{
      'content-type':'application/json; charset=utf-8',
      'cache-control':'no-store',
      'x-content-type-options':'nosniff',
      'x-r67-worker':WORKER_BUILD,
      ...extraHeaders
    }
  });
}

function round6(n){ return Math.round(Number(n)*1e6)/1e6; }
function round1(n){ return Math.round(Number(n)*10)/10; }

function rumboGrados(lat1,lon1,lat2,lon2){
  const toRad=Math.PI/180;
  const toDeg=180/Math.PI;
  const p1=lat1*toRad, p2=lat2*toRad;
  const dl=(lon2-lon1)*toRad;
  const y=Math.sin(dl)*Math.cos(p2);
  const x=Math.cos(p1)*Math.sin(p2)-Math.sin(p1)*Math.cos(p2)*Math.cos(dl);
  return (Math.atan2(y,x)*toDeg+360)%360;
}

function distanciaMetros(lat1,lon1,lat2,lon2){
  const R=6371000;
  const r=Math.PI/180;
  const p1=lat1*r,p2=lat2*r;
  const dp=(lat2-lat1)*r,dl=(lon2-lon1)*r;
  const a=Math.sin(dp/2)**2 + Math.cos(p1)*Math.cos(p2)*Math.sin(dl/2)**2;
  return 2*R*Math.atan2(Math.sqrt(a),Math.sqrt(1-a));
}

function boundsFromXY(x,y){
  const south=y*CFG.stepLat-90;
  const west=x*CFG.stepLon-180;
  return {south,west,north:south+CFG.stepLat,east:west+CFG.stepLon};
}

function intersectsCoverage(b){
  const c=CFG.coverage;
  return !(
    b.north < c.south || b.south > c.north ||
    b.east < c.west || b.west > c.east
  );
}

function validInt(v){
  return /^-?\d+$/.test(String(v ?? ''));
}

async function fetchWithTimeout(url,opts={},timeoutMs=CFG.timeoutMs){
  const controller=new AbortController();
  const timer=setTimeout(()=>controller.abort('timeout'),timeoutMs);
  try{
    return await fetch(url,{...opts,signal:controller.signal});
  }finally{
    clearTimeout(timer);
  }
}

async function consultarOverpass(bounds){
  const {south,west,north,east}=bounds;
  const query=
    '[out:json][timeout:14];' +
    'way["highway"~"' + CFG.highwayRegex + '"]' +
    '(' + south.toFixed(6) + ',' + west.toFixed(6) + ',' +
          north.toFixed(6) + ',' + east.toFixed(6) + ');' +
    'out geom;';

  let ultimoError=null;
  for(const endpoint of CFG.overpass){
    const iniciadoMs=Date.now();
    const host=new URL(endpoint).host;
    try{
      // Private.coffee recomienda POST (evita una URL larga para la consulta Overpass).
      const r=await fetchWithTimeout(endpoint,{
        method:'POST',
        headers:{
          'accept':'application/json',
          'content-type':'application/x-www-form-urlencoded; charset=UTF-8',
          'user-agent':'piOca-R67-road-geometry/1.1 (+https://trackingpioca.com)'
        },
        body:new URLSearchParams({data:query}).toString()
      });
      if(!r.ok){
        console.warn('[R67][Overpass] HTTP',host,r.status,'duracion_ms',Date.now()-iniciadoMs);
        ultimoError=new Error('Overpass '+r.status);
        continue;
      }
      const data=await r.json();
      if(data && Array.isArray(data.elements) && data.elements.length > 0){
        return data;
      }
      // Una respuesta HTTP 200 vacía no demuestra ausencia de calles:
      // probar el segundo servidor antes de reportar una falla temporal.
      console.warn('[R67][Overpass] sin elementos',host,'duracion_ms',Date.now()-iniciadoMs);
      ultimoError=new Error('Overpass sin elementos viales');
    }catch(e){
      console.warn('[R67][Overpass] fallo',host,'duracion_ms',Date.now()-iniciadoMs,
        'detalle',String(e?.message || e || 'error'));
      ultimoError=e;
    }
  }
  throw ultimoError || new Error('Overpass no disponible');
}

function compactarSector(data,id,bounds){
  const s=[];
  let ways=0;

  for(const el of (data.elements || [])){
    if(
      el?.type !== 'way' ||
      !el.tags ||
      !TIPO_INDEX.has(el.tags.highway) ||
      !Array.isArray(el.geometry) ||
      el.geometry.length < 2
    ) continue;

    ways++;
    const nodes=Array.isArray(el.nodes) ? el.nodes : [];
    const tipo=TIPO_INDEX.get(el.tags.highway);

    for(let i=0;i<el.geometry.length-1;i++){
      const a=el.geometry[i], b=el.geometry[i+1];
      if(!a || !b) continue;
      const lat1=Number(a.lat),lon1=Number(a.lon),lat2=Number(b.lat),lon2=Number(b.lon);
      if(![lat1,lon1,lat2,lon2].every(Number.isFinite)) continue;
      const largo=distanciaMetros(lat1,lon1,lat2,lon2);
      if(!Number.isFinite(largo) || largo<1.5) continue;

      s.push([
        el.id,
        i,
        nodes[i] ?? (String(el.id)+'a'+i),
        nodes[i+1] ?? (String(el.id)+'b'+(i+1)),
        round6(lat1),round6(lon1),round6(lat2),round6(lon2),
        round1(rumboGrados(lat1,lon1,lat2,lon2)),
        tipo
      ]);
    }
  }

  return {
    v:1,
    cv:CFG.version,
    id,
    b:[round6(bounds.south),round6(bounds.west),round6(bounds.north),round6(bounds.east)],
    t:TIPOS,
    s,
    meta:{ways,segments:s.length,generated_at:new Date().toISOString(),source:'OpenStreetMap'}
  };
}

async function sectorResponse(request,env,ctx){
  const url=new URL(request.url);
  const xs=url.searchParams.get('x');
  const ys=url.searchParams.get('y');
  const version=url.searchParams.get('v') || CFG.version;

  if(version !== CFG.version){
    return json({ok:false,error:'version_cartografia_no_compatible',expected:CFG.version},409);
  }
  if(!validInt(xs) || !validInt(ys)){
    return json({ok:false,error:'sector_invalido'},400);
  }

  const x=Number(xs),y=Number(ys);
  const bounds=boundsFromXY(x,y);
  if(!intersectsCoverage(bounds)){
    return json({ok:false,error:'fuera_de_cobertura_r67'},404);
  }

  const id=String(y)+'_'+String(x);

  /*
    Prioridad 1: sector estático ya subido dentro de /roads/s/.
    Esto permite congelar la cartografía propia piOca® sin tocar index.html.
  */
  try{
    const staticUrl=new URL('/roads/s/'+id+'.json',request.url);
    const staticResp=await env.ASSETS.fetch(new Request(staticUrl.toString(),{method:'GET'}));
    // Evitar servir un fallback HTML de Pages como si fuera geometría JSON.
    if(staticResp && staticResp.ok &&
       /application\/json/i.test(staticResp.headers.get('content-type') || '')){
      const h=new Headers(staticResp.headers);
      h.set('cache-control','public, max-age=86400, s-maxage='+CFG.cacheSeconds);
      h.set('x-r67-cache','STATIC');
      h.set('x-r67-worker',WORKER_BUILD);
      h.set('x-r67-sector',id);
      return new Response(staticResp.body,{status:200,headers:h});
    }
  }catch(_e){}

  const canonical=new URL(request.url);
  canonical.pathname='/__r67/cache/'+CFG.version+'/'+id;
  canonical.search='';
  const cacheKey=new Request(canonical.toString(),{method:'GET'});
  const cache=caches.default;

  const cached=await cache.match(cacheKey);
  if(cached){
    const h=new Headers(cached.headers);
    h.set('x-r67-cache','HIT');
    h.set('x-r67-worker',WORKER_BUILD);
    return new Response(cached.body,{status:cached.status,headers:h});
  }

  try{
    const raw=await consultarOverpass(bounds);
    const payload=compactarSector(raw,id,bounds);
    if(payload.s.length===0){
      // No confundir geometría no disponible con ruta inexistente/404.
      return json({ok:false,error:'sector_sin_vias',id},503,{'retry-after':'10'});
    }

    const body=JSON.stringify(payload);
    const response=new Response(body,{
      status:200,
      headers:{
        'content-type':'application/json; charset=utf-8',
        'cache-control':'public, max-age=86400, s-maxage='+CFG.cacheSeconds+', stale-while-revalidate=86400',
        'x-r67-cache':'MISS',
        'x-r67-sector':id,
        'x-r67-worker':WORKER_BUILD,
        'x-content-type-options':'nosniff'
      }
    });

    // La escritura de caché no bloquea la respuesta de geometría al cliente.
    try{
      const guardar=cache.put(cacheKey,response.clone());
      if(ctx && typeof ctx.waitUntil === 'function'){
        ctx.waitUntil(guardar.catch(()=>{}));
      }else{
        await guardar.catch(()=>{});
      }
    }catch(_e){}
    return response;
  }catch(error){
    console.error('[R67][sector] geometria no disponible',id,
      'detalle',String(error?.message || error || 'error'));
    return json({
      ok:false,
      error:'geometria_temporalmente_no_disponible',
      id,
      detail:String(error?.message || error || 'error')
    },503,{'retry-after':'3'});
  }
}

export default {
  async fetch(request,env,ctx){
    const url=new URL(request.url);

    if(url.pathname === '/__r67/health'){
      return json({
        ok:true,
        worker_active:true,
        worker_build:WORKER_BUILD,
        version:CFG.version,
        step_lat:CFG.stepLat,
        step_lon:CFG.stepLon,
        coverage:CFG.coverage
      },200,{'cache-control':'no-store'});
    }

    // Diagnóstico liviano: valida índice/cobertura sin consultar Overpass.
    if(url.pathname === '/__r67/check'){
      const xs=url.searchParams.get('x'),ys=url.searchParams.get('y');
      if(!validInt(xs) || !validInt(ys)){
        return json({ok:false,error:'sector_invalido'},400);
      }
      const x=Number(xs),y=Number(ys);
      if(!Number.isSafeInteger(x) || !Number.isSafeInteger(y)){
        return json({ok:false,error:'sector_invalido'},400);
      }
      return json({ok:true,worker_build:WORKER_BUILD,
        sector:String(y)+'_'+String(x),dentro_cobertura:intersectsCoverage(boundsFromXY(x,y))});
    }

    if(url.pathname === '/__r67/sector'){
      if(request.method !== 'GET'){
        return json({ok:false,error:'method_not_allowed'},405,{allow:'GET'});
      }
      return sectorResponse(request,env,ctx);
    }

    return env.ASSETS.fetch(request);
  }
};
